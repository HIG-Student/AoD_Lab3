package se.hig.aod.lab3;

/**
 * 
 *
 * @author Viktor Hanstorp (ndi14vhp@student.hig.se)
 */
public class MyInt implements Comparable<MyInt>
{
    public final String desc;
    public final Integer value;

    /**
     * 
     */
    public MyInt(Integer value, String desc)
    {
        this.value = value;
        this.desc = desc;
    }

    /**
     * {@inheritDoc}
     **/
    @Override
    public int compareTo(MyInt arg0)
    {
        return value - arg0.value;
    }

    @Override
    public String toString()
    {
        return value + " [" + desc + "]";
    }
    
    public static void main(String[] args)
    {
        MyBSTPriorityQueue<MyInt> queue = new MyBSTPriorityQueue<MyInt>();
        
        queue.enqueue(new MyInt(1000, "1"));
        queue.enqueue(new MyInt(1000, "2"));
        queue.enqueue(new MyInt(1000, "3"));
        queue.enqueue(new MyInt(2000, "4"));
        queue.enqueue(new MyInt(1000, "5"));
        queue.enqueue(new MyInt(1000, "6"));
        
        queue.print();
    }
}
